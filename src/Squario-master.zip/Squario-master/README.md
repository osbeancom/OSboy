# Squario
### 5/25/16 Update:
Mushrooms picked up after becoming big Squario will fill him, up to 5 times  
Added underworld background and flipped the pipes to the ceiling

### 5/22/16 Update:
Added pipes to break up levels, levels get progressively longer  
Every other level has more of an underworld layout now  
Starmen and thunder bolts should only spawn towards the second half of each level  
Every 20 coins you earn an extra life  
Cleaned up hit detection  
Lots of random backend cleanup and other things I already forgot about  
