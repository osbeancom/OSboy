#ifndef RECTS_H
#define RECTS_H

Rect topHole;
Rect bottomHole;
Rect wall[4];
Rect playerRect;

#endif
