/*******************************************************************************
 * Copyright (c) 2015 Andrew Low.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Andrew Low - initial implementation
 *******************************************************************************/
 
#include <avr/pgmspace.h>
#ifndef FLIGHT_H
#define FLIGHT_H

extern const unsigned char flight1[]; 

#endif
