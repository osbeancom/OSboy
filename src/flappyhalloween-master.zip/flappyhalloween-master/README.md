# flappyhalloween
An Arduboy game

## Description

Flappy Halloween is best categorized as a side-scrolling game. My 10yr old created the
concept, made the graphics and did the game play testing.

## Controls:
* A - start the game
* Up / Down - control your bat

## Goals:
* Eat the bugs
* Avoid the owl

## Installation
1. Download Zip or Git Clone from: https://github.com/andrewlow/flappyhalloween
2. Open flappyhalloween.ino with Arduino IDE
3. Upload to your Arduboy
