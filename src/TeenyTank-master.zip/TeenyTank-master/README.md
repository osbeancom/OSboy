# TeenyTank
TeenyTank fun little multiplayer game for the Arduboy.

At the moment, it is for 2 players, and has randomly generated levels, graphics, and sound effects.

The controls are fairly simple:
- Left/Right: Aim
- Up/Down: Adjust Power
- B (gameboy A): Fire
- A (gameboy B): Hold down for fine aim/power control

Have fun!
