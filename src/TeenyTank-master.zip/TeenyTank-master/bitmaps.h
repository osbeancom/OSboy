#ifndef BITMAPS_H
#define BITMAPS_H

#include <avr/pgmspace.h>

extern const unsigned char tankfill[];
extern const unsigned char tankline[];

#endif // BITMAPS_H

