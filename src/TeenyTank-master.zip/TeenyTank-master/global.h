#ifndef GLOBAL_H
#define GLOBAL_H

struct Tank {
  short x;
  short y;
  short health;
  double aim;
  double power;
};

#endif


