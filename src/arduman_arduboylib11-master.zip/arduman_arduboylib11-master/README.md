# Ardu-man

For Arduboy lib 1.1 and the consumer Arduboy device

It's Ardu-man!  A game not completely dissimilar from pac-man.

Play it in your browser too! www.rtsoft.com/arduman.html

Version history:

V1.00:  Initial release

Credits:

Programming/music/etc:  Seth A. Robinson

Thanks to:

- The arduboy team
- foupy and his cool image converter: http://fuopy.github.io/arduboy-image-converter/
- miditones for midi conversion
- Highscore code by nootropic design

Contact:

seth@rtsoft.com
www.rtsoft.com
