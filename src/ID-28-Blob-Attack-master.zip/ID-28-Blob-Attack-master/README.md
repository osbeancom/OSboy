# Blob Attack
![Image]
(http://www.team-arg.org/masterfiles/team-arg-blba/images/banner-ID-28c.png)

Blob Attack : http://www.team-arg.org/blba-manual.html  
**Download latest Arduboy version and source :** https://github.com/TEAMarg/ID-28-Blob-Attack/releases/latest  
MADE by TEAM a.r.g. : http://www.team-arg.org/more-about.html
 
2015 - Game by JO3RI - All art by CastPixel: https://twitter.com/castpixel

Thanks to MLXXXp for his help on switching from ARGlib to the Arduboy 2 library

Game License: MIT : https://opensource.org/licenses/MIT
