#define FILE_NAME "RAYNEN"
#define FILE2_NAME "RAYNEH"
#define FILE_SIZE 9
struct game_data_struct{
  uint32_t copper;
  int8_t cold;
  int8_t acid;
  int8_t luck;
  int8_t invisibility;
  int8_t speed_boost;
} ;
