#include "Weapons.h"
#include <stdio.h>


Weapons::Weapons() {

}

