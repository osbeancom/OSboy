#ifndef _MAIN_MENU_H
#define _MAIN_MENU_H

#include "game.h"

unsigned char displayMainMenu();

#endif
