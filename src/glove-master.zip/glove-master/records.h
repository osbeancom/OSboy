#ifndef _RECORDS_H
#define _RECORDS_H_

void displayRecords();

#endif
