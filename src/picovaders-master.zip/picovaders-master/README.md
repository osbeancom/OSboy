# picovaders
## Description
picovaders is a space invaders-like shooting game for Arduboy.

## Instructions
Move the cannon and hit the aliens and UFOs.

You have 3 cannons. One cannon will be added when your score reached 1500 points.

* Start : A button, or B button for silent mode.
* Move : LEFT and RIGHT 

## Installation

1. Download Zip or Git Clone from: https://github.com/boochow/picovaders
2. Open picovaders.ino with Arduino IDE
3. Upload to your Arduboy

## Tips
You may need a magnifying glass :-)
