# ArduboyWorks
Making mini games for [Arduboy](https://www.arduboy.com/).

* OBN-Y01 [Hollow Seeker](http://community.arduboy.com/t/hollow-seeker-a-simple-action-game/2594)
 * Go forward in right direction. Seek a hollow as refuge not to be crushed.
