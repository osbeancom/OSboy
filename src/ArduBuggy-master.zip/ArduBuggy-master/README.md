# ArduBuggy
A simple game inspired by ardade game Moon Patrol


Try to reach 20000 point faster as you can, jumping and firing over 6 level.

Manage your ammo for last two level.


RIGHT: move forward and increase your speed

LEFT:  brake

A:     fire

B:     Jump

UP:    fx-on

DOWN:  fx-off


