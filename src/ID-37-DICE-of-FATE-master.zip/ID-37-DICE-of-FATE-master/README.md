#DICE of FATE
![Image]
(http://www.team-arg.org/masterfiles/team-arg-dice/images/banner-ID-37.png)

Digital Dice : http://www.team-arg.org/dice-manual.html  
**Download latest Arduboy version and source :** https://github.com/TEAMarg/ID-37-DICE-of-FATE/releases/latest  
MADE by TEAM a.r.g. : http://www.team-arg.org/more-about.html

2016 - CASTPIXEL - JO3RI

Thanks to MLXXXp for his help on switching from ARGlib to the Arduboy 2 library

Game License: MIT : https://opensource.org/licenses/MIT
