# ideas on the zombie game

## title ideas
- trailer trash
- Virus X

## game ideas

## game mechanics ideas

## game playground ideas

##game elements ideas
