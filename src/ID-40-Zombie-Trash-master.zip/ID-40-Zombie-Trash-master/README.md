# ID-40-Zombie-Trash
Code for the game Zombie Trash for Arduboy
