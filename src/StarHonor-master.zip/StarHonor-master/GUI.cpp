#include "GUI.h"

Vector2d** OverviewLocations;
Vector2d** CombatLocations;

bool AcceptMenuInput;

SelectionArrow* RepairSelectionArrow;
SelectionArrow* CurrentSelectionArrow;
SelectionArrow* CombatSelectionArrow;
