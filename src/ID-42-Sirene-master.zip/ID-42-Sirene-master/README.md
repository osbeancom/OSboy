# Sirène
![Image](http://www.team-arg.org/masterfiles/team-arg-srn/images/banner-ID-42.png)

Sirène : http://www.team-arg.org/srn-manual.html  
**Download latest Arduboy version and source :** https://github.com/TEAMarg/ID-42-Sirene/releases/latest  
MADE by TEAM a.r.g. : http://www.team-arg.org/more-about.html
 
2016 - JUSTIN CYR - JO3RI

Thanks to MLXXXp for his help on switching from ARGlib to the Arduboy 2 library

Game License: MIT : https://opensource.org/licenses/MIT
