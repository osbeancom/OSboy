#Mystic Balloon
![Image]
(http://www.team-arg.org/masterfiles/team-arg-mybl/images/banner-ID-34.png)

Mystic Balloon : http://www.team-arg.org/mybl-manual.html  
**Download latest Arduboy version and source :**https://github.com/TEAMarg/ID-34-Mystic-Balloon/releases/latest  
MADE by TEAM a.r.g. : http://www.team-arg.org/more-about.html
 
2016 - GEVANO - CASTPIXEL - JO3RI

Thanks to MLXXXP for his help on switching from ARGlib to the Arduboy 2 library

Game License: MIT : https://opensource.org/licenses/MIT
