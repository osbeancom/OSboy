#include <avr/pgmspace.h>
#ifndef BITMAPS_H
#define BITMAPS_H

extern const unsigned char arduboyBitmap[];
extern const unsigned char title[];

#endif
