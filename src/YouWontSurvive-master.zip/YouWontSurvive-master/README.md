# You Won't Survive

A simple game for Arduboy! Avoid incoming enemies on two different modes and test your reflexes. 
But remember ...surviving is hard in this one. Good luck!

# Instructions

Move your character by pressing UP and DOWN. Don't get hit by incoming enemies. For every survived enemy you win a point! But don't get too self-confident.
- HIGHSCORE: 30

# Installation

1. Download Zip or Git Clone from: https://github.com/AstroAndre/YouWontSurvive
2. Open youwontsurvive.ino with Arduino IDE
3. Upload to your Arduboy
