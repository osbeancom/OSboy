# MicroCheckers
Multiplayer Checkers for the Arduboy!

Controls:
- Use the arrow keys to move the selection
- Press 'b' on a piece to select it, and then press 'b' on the square you want to move it to.
- Press 'a' to cancel your selection.
- Once you're done with your move, pass the Arduboy to the other player!

Other tips:
- There is forced capture, so if you can jump over a piece, you have to.
- There's no win screen at the moment, but you win when you remove all your oponent's pieces.
- To play again, simply restart the Arduboy.
