#include <avr/pgmspace.h>
#include "Squawk.h"
#ifndef TUNES_H
#define TUNES_H

extern Melody TheOriginalSquawk[];
#endif
