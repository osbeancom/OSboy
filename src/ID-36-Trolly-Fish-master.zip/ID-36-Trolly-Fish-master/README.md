#Trolly Fish
![Image]
(http://www.team-arg.org/masterfiles/team-arg-fish/images/banner-ID-36.png)

Trolly Fish : http://www.team-arg.org/fish-manual.html  
**Download latest Arduboy version and source :** https://github.com/TEAMarg/ID-36-Trolly-Fish/releases/latest  
MADE by TEAM a.r.g. : http://www.team-arg.org/more-about.html

2016 - GAVENO - JO3RI - JUSTIN CRY

Thanks to MLXXXp for his help on switching from ARGlib to the Arduboy 2 library

Game License: MIT : https://opensource.org/licenses/MIT
