# Shadow Runner
![Image]
(http://www.team-arg.org/masterfiles/team-arg-shrun/images/banner-ID-15b.png)

SHADOW RUNNER: http://www.team-arg.org/shrun-manual.html  
**Download latest Arduboy version and source :** https://github.com/TEAMarg/ID-15-Shadow-Runner/releases/latest  
MADE by TEAM a.r.g. : http://www.team-arg.org/about.html

2015 - JO3RI - Trodoss

Special thanks to Dreamer3 for helping with the conversion from Gamby

Thanks to MLXXXp for his help on switching from ARGlib to Arduboy 2 library

Game License: MIT : https://opensource.org/licenses/MIT
