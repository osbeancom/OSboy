#define SOUND_PIN     9

void sound_play (int noteFrequency);
void sound_hit_stone();
void sound_hit_bird();
void sound_extra_life();
