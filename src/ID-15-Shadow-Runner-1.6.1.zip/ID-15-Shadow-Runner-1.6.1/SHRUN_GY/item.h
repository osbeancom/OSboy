void stone1_draw();
void stone2_draw();
void bird1_draw ();
void bird2_draw ();
void bird3_draw ();
void heart_draw();
