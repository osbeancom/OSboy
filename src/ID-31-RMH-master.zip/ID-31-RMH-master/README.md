# Reverse Mermaid Hockey  
![Image](http://www.team-arg.org/masterfiles/team-arg-rmh/images/banner-ID-31.png)

Reverse Mermaid Hockey : http://www.team-arg.org/rmh-manual.html  
**Download latest Arduboy version and source :** https://github.com/TEAMarg/ID-31-RMH/releases/latest  
MADE by TEAM a.r.g. : http://www.team-arg.org/more-about.html

2015 - DRAGULA96 - ART WORK: JO3RI & UNCLESPORKY

Thanks to MLXXXp for his help on switching from ARGlib to the Arduboy 2 library

Game License: MIT : https://opensource.org/licenses/MIT
