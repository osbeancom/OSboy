# tres
Threes! clone for the Arduboy game system

/*
  Title: Tres
  Author: cajogold (Casey Gold)
  Date:  FEB/2017
  
  What is it: Clone/Port/Rip-off of the game Threes! for mobile phones.
  
  Credit to Team A.R.G. for a good bit of the code structure.  Specificaly the state machine and eeprom.
*/
