# CascadePath

Cascade Path uses a customized version of the Arduboy library. Be sure to specify which board you are using in core.h (lines 25-26) before uploading.

