# Humanity Revenge
<b>version 1.0.0.0</b>
##A (simple) Shoot 'Em Up for Arduboy

Humanity Revenge is a Shoot 'Em Up for Arduboy with innovative ideas, like shoot, shoot bomb, try to kill enemies and probably (very often) die.
You are alone with your (crappy) ship fighting aliens (or sort of), obviously in space, far away from your beloved earth!

You can choose, pressing B button, between three weapons (gun, split gun and laser) and shoot holding A button.
Pressing B while holding A will launch a bomb (start with 3 of them).
Being shot will decrease your lives (start with 3).

You can progress through six levels, encountering new enemies and a final boss. Probably you will die at some point because the game is not well calibrated.

There are three types of easy enemy that basically move from right to left trying to kill you (shooting or colliding). At level four, medium enemies should spawn (they are bigger and tougher). Level six is the final one, with big (not too big) boss.

There is no audio, no highscore saving, no pause, no led flashes, no code review, no comment in code ....i'm lazy.

### what you need
What you need to compile the game:
- Arduino Ide 1.6.9
- Arduboy Lib ver 1.1 [Quick Start Guide](http://community.arduboy.com/t/kickstarter-quick-start-guide/725)
- [Arduboy Extra](https://github.com/yyyc514/ArduboyExtra)
