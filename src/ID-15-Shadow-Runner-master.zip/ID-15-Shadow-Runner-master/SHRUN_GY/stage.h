void stage_update ();
void background_draw ();
void forground_draw ();
void ground_draw ();
void life_draw ();
void score_draw (int scoreX, int scoreY);
void items_draw ();
void items_update();
void items_collision();
void level_update();

