void candle_draw (char x,char y);
