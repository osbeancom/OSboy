void scenario1();
void scenario2();
void scenario3();

void scenario4();
void scenario5();
void scenario6();

void scenario7();
void scenario8();
void scenario9();

void scenario1EL();
void scenario2EL();
void scenario3EL();
void scenario4EL();

